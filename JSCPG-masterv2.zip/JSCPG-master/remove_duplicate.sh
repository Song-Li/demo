awk '!x[$0]++' succ.log > outfile.succ
