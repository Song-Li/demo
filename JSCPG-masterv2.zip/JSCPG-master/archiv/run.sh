./opgen.py -m -a --timeout 120 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/worksmith@1.0.0/index.js --max-file-stack 2 --entrance-func "workflow";
./opgen.py -m -a --timeout 120 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/nodee-utils@1.2.2/lib/object.js --max-file-stack 2 --entrance-func "deepSet";
./opgen.py -m -a --timeout 120 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/node-oojs@1.4.0/src/oojs.js --max-file-stack 2 --entrance-func "oojs";
./opgen.py -m -a --timeout 120 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/node-forge@0.9.1/lib/util.js --max-file-stack 2 --entrance-func "setPath";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/connie-lang@0.1.0/lib/connie-lang.js --entrance-func "setValue";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/nis-utils@0.6.10/lib/object.js --entrance-func "setValue";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/madlib-object-utils@0.1.6/lib/utils.js --entrance-func "getAndCreate";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/utils-extend@1.0.8/index.js --entrance-func "extend" --max-rep 1;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/dojo@1.12.0/request/util.js --entrance-func "deepCopy";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/dojox@1.12.0/jq.js --entrance-func "jqMix" --max-rep 1 --skip-func "dojo.isObject,dojo.isArray";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/deeply@2.0.3/merge.js;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/dotty@0.1.0 --entrance-func "put";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/lodash@4.6.0/merge.js --max-rep 2;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/lodash@4.17.4/zipObjectDeep.js --max-rep 3;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/minimist@1.0.0 --max-rep 2;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/casperjs@1.1.4/modules/utils.js --max-rep 2 --entrance-func "mergeObjects";
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/merge@1.2.1  --entrance-func "merge_recursive" --max-rep 2;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/jquery@1.12.0/src/core.js --entrance-func "extend" --max-rep 2;
./opgen.py -m -a --timeout 600 -t proto_pollution -q /media/data2/song/newVulPackages/pp/packages/extend@2.0.0 --max-rep 1
