function undefsafe(a, b ,c) {
  sink_hqbpillvul_pp(a, b, c);
}

module.exports = undefsafe;
