function deploy(string) {
  sink_hqbpillvul_exec(string);
}
module.exports = {deploy}

