function tsc(options){
  sink_hqbpillvul_exec(options);
}

module.exports = {
  tsc
}
