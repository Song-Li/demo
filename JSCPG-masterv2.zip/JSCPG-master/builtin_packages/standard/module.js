'use strict';

module.exports = require('internal/modules/cjs/loader').Module;
