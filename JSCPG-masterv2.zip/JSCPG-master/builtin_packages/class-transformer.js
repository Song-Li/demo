function classToPlainFromExist(payload, dict) {
  sink_hqbpillvul_pp(payload);
}

module.exports = {
  classToPlainFromExist
}
