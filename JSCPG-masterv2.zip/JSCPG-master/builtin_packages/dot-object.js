function set(a, b, c, d) {
  sink_hqbpillvul_pp(a,b, c, d);
}
module.exports = {set}
