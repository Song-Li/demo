function mongodb(name) {
  this.name = name;
}

function collection() {
}

mongodb.prototype.collection = function (collection_name) {
  var mid = collection_name + '123';
  // the name should be sanitized before using
  // we call a sink function here
  sink_hqbpillvul_db(mid);
  return new collection();
}

collection.prototype.insertOne = function (json) {
  var inside_json = json;
  sink_hqbpillvul_db(inside_json);
}

function MongoClient(url) {
  this.url = url;
}

MongoClient.prototype.db = function(name) {
  this.name = name;
  return new mongodb(this.name);
}

module.exports = {
  mongodb,
  MongoClient
};
