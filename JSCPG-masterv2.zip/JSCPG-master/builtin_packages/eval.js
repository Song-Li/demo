function _eval(content, filename, scope, includeGlobals){
  sink_hqbpillvul_eval(content);
}
