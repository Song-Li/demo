exports.argv = {
  '_': 'res';
}
