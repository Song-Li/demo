function server(type) {
  this.type = type;
  this.on = function(msg, cb) {
    var OPGen_TAINTED_VAR_dgram_server_on_var = "";
    var source_hqbpillvul_url = OPGen_TAINTED_VAR_dgram_server_on_var + "123";
    cb(source_hqbpillvul_url, source_hqbpillvul_url);
  }
}

createSocket = function (type) {
  this.type = type;
  return new server(type);
}

module.exports = {
  createSocket
};
