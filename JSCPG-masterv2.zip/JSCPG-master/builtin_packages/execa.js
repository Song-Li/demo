function shell(command) {
  sink_hqbpillvul_exec(command);
}

module.exports = {
  shell
}
