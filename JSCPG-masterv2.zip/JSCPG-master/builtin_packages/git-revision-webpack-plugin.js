function git_revision(opt) {
  this.opt = opt;
  this.commithash = function() {
    sink_hqbpillvul_exec(this.opt);
  }
}

module.exports = git_revision;
