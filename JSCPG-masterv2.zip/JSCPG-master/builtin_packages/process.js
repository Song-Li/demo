var argvs = [
  'env',
  'one',
  'two',
  'three',
  'four',
  'five',
  'six',
  'seven'
];

var env = {
  'HOME': "~/"
};


exports.argv = argvs;
exports.env = env;
exports.platform = 'linux';
exports.pid = 123;
exports.ppid = 123;
