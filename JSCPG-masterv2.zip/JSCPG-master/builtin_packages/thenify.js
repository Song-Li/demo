function thenify(a) {
  sink_hqbpillvul_code_execution(a);
}

module.exports = thenify;
