rm ./*.log;
#rm testnodes.csv testrels.csv 
rm -f vul_func_names.csv package-lock.json;
rm -rf ./tmp_env;
rm -rf ./net_env_dir;
