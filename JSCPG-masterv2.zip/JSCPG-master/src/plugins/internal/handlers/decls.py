from src.plugins.handler import Handler

class HandleDecls(Handler):
    def process(self):
        elif node_type in ['AST_IF', 'AST_IF_ELEM', 'AST_FOR', 'AST_FOREACH',
            'AST_WHILE', 'AST_SWITCH', 'AST_SWITCH_CASE', 'AST_EXPR_LIST']:
        decl_vars_and_funcs(self.G, child, var=var, func=False)
