modeled_builtin_lists = {
    'array': ['push',
        'pop',
        'unshift',
        'shift',
        'join',
        'forEach',
        'keys',
        'values', 
        'entries', 
        'splice',
        'slice', 
        'filter', 
        'map', 
        'reduce', 
        'concat']
}