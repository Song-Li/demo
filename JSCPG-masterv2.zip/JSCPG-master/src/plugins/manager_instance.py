from .manager import PluginManager
_ = PluginManager()
internal_manager = PluginManager()
