import requests

# host = "http://localhost:8000"
host = "http://172.31.22.200:5001"

def send_messge(message, endpoint=f"{host}/v1/system_status"):
    try:
        requests.post(endpoint, timeout=0.1, json={
            "status_message": message,
            "tool_name": "OPGen",
        })
    except:
        pass
