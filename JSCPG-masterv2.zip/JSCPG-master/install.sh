cd ./src/esprima/ && npm i && cd -;
npm install \
    @babel/core \
    @babel/cli \
    @babel/preset-env \
    @babel/preset-typescript \
    mocha;
python3 -m pip install -r ./requirements.txt;

