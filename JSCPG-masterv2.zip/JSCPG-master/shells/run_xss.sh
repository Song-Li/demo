./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/buildseverlzz@1.0.0
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/hxsstatic@1.0.8
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/lserver@1.0.9
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/lymph-server@1.2.0
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/lyss@0.0.1
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/min-http@1.0.6 --babel ~/packages/xss/packages/min-http@1.0.6/
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/node-servers@1.0.3
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/sheepy@0.1.1
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/simple_server@0.1.0
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/simplewebserver@1.2.0
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/xxx-server-yyy@1.0.1
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/zzl-selver@1.0.3
./opgen.py -t xss -maq --timeout 600 ~/packages/xss/packages/zzl-server@1.0.5
