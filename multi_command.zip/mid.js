var end = require("end.js");
function mid(input) {
  var to_end = input + "test1";
  end.end(to_end);
  fake(to_end);
  var useless = "start";
  finalVar = useless + "1";
  fake(finalVar);
}

function nothing(input) {
  var second = input + "1";
  fake(second);
}

module.exports = {
  foo: mid
}
